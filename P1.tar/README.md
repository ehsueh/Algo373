Algo373
=======

Algo373 Coding Project

Grace Lin 
Emma Hsueh 998968951 

Q1 hop
Q2 monkey
are done in python

Q3 boxes
Q4 business (our approximation attempt)
are done in c++

To compile please use the c++ -fpermissive flag.
Thanks!
